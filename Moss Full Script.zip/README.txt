perl path_to/moss.pl -l [language] [file_1 file_2 file_3 ... file_n]

Ex: perl ~/Desktop/moss.pl -l c source.c code.c
